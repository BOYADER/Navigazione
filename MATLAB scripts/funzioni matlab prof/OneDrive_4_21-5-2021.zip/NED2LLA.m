function LLA = NED2LLA(LLA0,NED)

LLA0Rad = zeros(2, 1);
LLA = zeros(2, 1);

for i=1:2
    LLA0Rad(i, 1) = LLA0(i, 1)*pi/180;
end

a = 6378137.0;
f = 1 / 298.257223563;
Rn = a / sqrt(1 - (2 * f - f * f) * sin(LLA0Rad(1, 1)) * sin(LLA0Rad(1, 1)));
Rm = Rn * (1 - (2 * f - f * f)) / (1 - (2 * f - f * f) * sin(LLA0Rad(1, 1)) * sin(LLA0Rad(1, 1)));

LLA(1,1) = (LLA0Rad(1,1) + atan2(1,Rm) * NED(1,1)) * 180.0/pi;
LLA(2,1) = (LLA0Rad(2,1) + atan2(1,Rn * cos(LLA0Rad(1, 1))) * NED(2,1)) * 180.0/pi;